</html>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Landing</title>
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <style>
        .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 20px 100px;
            background-color: #106EFD;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg bg-primary">
        <div class="container">
            <a class="navbar-brand fs-4 text-white" href="index.php">WEBSITE GALERI FOTO</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse mt-2" id="navbarNavAltMarkup">
                <div class="navbar-nav me-auto">

                </div>
                <a href="login.php" class="btn btn-outline-dark m-1">Masuk</a>
                <a href="register.php" class="btn btn-outline-warning m-1">Daftar</a>

            </div>
        </div>
    </nav>



    <footer class="d-flex justify-content-center border-top mt-3 bg-light fixed-bottom">
        <p>&copy; UKK RPL 2024 | Akbar Fauzan Septiansyah</p>
    </footer>

    <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>